package classes;
/**
 * Demonstration of interface.
 */
public interface Student {
   
    boolean registerStudent();
    void displayStudentinfo();
    
    
}
