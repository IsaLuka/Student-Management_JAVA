package classes;
//main class
public class mainClass {

  public static void main(String[] args) {
    Courses student = new Courses();
        student.menu();
  }

}
